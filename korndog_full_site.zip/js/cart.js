document.addEventListener("DOMContentLoaded", () => {
  const cartList = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  function renderCart() {
    cartList.innerHTML = "";
    let total = 0;
    cart.forEach((item, index) => {
      total += item.price;
      const li = document.createElement("li");
      li.textContent = `${item.title} - $${item.price}`;
      const removeBtn = document.createElement("button");
      removeBtn.textContent = "Remove";
      removeBtn.onclick = () => {
        cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCart();
      };
      li.appendChild(removeBtn);
      cartList.appendChild(li);
    });
    cartTotal.textContent = "Total: $" + total.toFixed(2);
  }

  renderCart();

  document.getElementById("checkout").onclick = () => {
    if (cart.length === 0) {
      alert("Your cart is empty!");
      return;
    }
    // Redirect to PayPal checkout
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    window.location.href = `https://www.paypal.com/ncp/payment?amount=${total.toFixed(2)}&business=titans.rule1215@gmail.com`;
  };
});
