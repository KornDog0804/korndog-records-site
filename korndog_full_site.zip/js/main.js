document.addEventListener("DOMContentLoaded", () => {
  fetch("records.json")
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("record-list");
      if (!list) return;
      list.innerHTML = "";
      data.forEach(record => {
        const div = document.createElement("div");
        div.className = "record";
        div.innerHTML = `
          <img src="${record.image}" alt="${record.title}" />
          <h3>${record.title}</h3>
          <p>${record.grade} - $${record.price}</p>
          <button onclick="addToCart('${record.title}', ${record.price})">Add to Cart</button>
        `;
        list.appendChild(div);
      });
    });
});

function addToCart(title, price) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push({ title, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(title + " added to cart!");
}
