/**
 * KornDog Records - Hidden Admin Access
 * Activates admin panel when Zombie Kitty is clicked 5 times
 */

// Counter for kitty clicks
let kittyClickCount = 0;
const REQUIRED_CLICKS = 5;
const ADMIN_PASSWORD = "KornDog2025!";

// Initialize admin access functionality
document.addEventListener('DOMContentLoaded', function() {
  // Find Zombie Kitty in about section
  const aboutSection = document.getElementById('aboutSection');
  if (aboutSection) {
    // Look for kitty image in the about section
    setupKittyClickListener();
    
    // Also set up admin button functionality if it exists
    setupAdminButton();
  }
});

// Set up click listener on Zombie Kitty image
function setupKittyClickListener() {
  // Try to find the kitty image in various ways to ensure compatibility
  const kittySelectors = [
    '.mascot-image[src*="zombie_kitty"]',
    '.mascot-image[src*="Screenshot_20250827"]',
    'img[alt*="Zombie Kitty"]',
    '.kitty-showcase img',
    '#zombieKitty img'
  ];
  
  // Try each selector
  let kittyImage = null;
  for (const selector of kittySelectors) {
    kittyImage = document.querySelector(selector);
    if (kittyImage) break;
  }
  
  // If we found the kitty image, add click listener
  if (kittyImage) {
    kittyImage.style.cursor = 'pointer';
    kittyImage.addEventListener('click', handleKittyClick);
    console.log('Admin access: Kitty click listener set up');
  } else {
    // If we couldn't find the kitty image directly, set up a mutation observer
    // to watch for when it might be added to the DOM
    setupMutationObserver();
  }
}

// Handle clicks on the kitty image
function handleKittyClick(event) {
  event.preventDefault();
  event.stopPropagation();
  
  kittyClickCount++;
  
  // Add a subtle visual feedback
  const kittyImage = event.target;
  kittyImage.style.transition = 'transform 0.2s ease';
  kittyImage.style.transform = 'scale(1.1)';
  setTimeout(() => {
    kittyImage.style.transform = 'scale(1)';
  }, 200);
  
  console.log(`Admin access: Kitty clicked ${kittyClickCount} times`);
  
  // Check if we've reached the required number of clicks
  if (kittyClickCount >= REQUIRED_CLICKS) {
    kittyClickCount = 0; // Reset counter
    promptAdminPassword();
  } else if (kittyClickCount === REQUIRED_CLICKS - 1) {
    // Give a hint on the penultimate click
    const hint = document.createElement('div');
    hint.textContent = "One more click...";
    hint.style.position = 'absolute';
    hint.style.color = 'white';
    hint.style.fontSize = '12px';
    hint.style.opacity = '0.7';
    hint.style.bottom = '-20px';
    hint.style.left = '50%';
    hint.style.transform = 'translateX(-50%)';
    hint.style.textShadow = '0 0 3px rgba(0,0,0,0.5)';
    hint.style.pointerEvents = 'none';
    
    // Add hint near the kitty
    const kittyContainer = kittyImage.parentElement;
    if (kittyContainer) {
      kittyContainer.style.position = 'relative';
      kittyContainer.appendChild(hint);
      
      // Remove hint after 2 seconds
      setTimeout(() => {
        if (hint.parentElement) {
          hint.parentElement.removeChild(hint);
        }
      }, 2000);
    }
  }
}

// Prompt for admin password
function promptAdminPassword() {
  // Create a custom modal for password entry instead of using browser prompt
  const modalOverlay = document.createElement('div');
  modalOverlay.className = 'admin-password-overlay';
  modalOverlay.style.position = 'fixed';
  modalOverlay.style.top = '0';
  modalOverlay.style.left = '0';
  modalOverlay.style.width = '100%';
  modalOverlay.style.height = '100%';
  modalOverlay.style.backgroundColor = 'rgba(0,0,0,0.8)';
  modalOverlay.style.display = 'flex';
  modalOverlay.style.justifyContent = 'center';
  modalOverlay.style.alignItems = 'center';
  modalOverlay.style.zIndex = '9999';
  
  // Create modal content
  const modalContent = document.createElement('div');
  modalContent.className = 'admin-password-modal';
  modalContent.style.background = 'linear-gradient(135deg, #3b2aa2, #0fa77f)';
  modalContent.style.padding = '2rem';
  modalContent.style.borderRadius = '12px';
  modalContent.style.boxShadow = '0 10px 25px rgba(0,0,0,0.3)';
  modalContent.style.width = '90%';
  modalContent.style.maxWidth = '400px';
  modalContent.style.textAlign = 'center';
  
  // Create modal header
  const modalHeader = document.createElement('h3');
  modalHeader.textContent = 'Admin Access';
  modalHeader.style.color = 'white';
  modalHeader.style.marginBottom = '1.5rem';
  modalHeader.style.fontFamily = "'Permanent Marker', cursive";
  modalHeader.style.fontSize = '1.8rem';
  
  // Create zombie kitty image
  const kittyImage = document.createElement('img');
  kittyImage.src = 'images/zombie_kitty.png'; // Update path as needed
  kittyImage.alt = 'Zombie Kitty Admin';
  kittyImage.style.width = '80px';
  kittyImage.style.height = '80px';
  kittyImage.style.objectFit = 'contain';
  kittyImage.style.margin = '0 auto 1.5rem';
  kittyImage.style.display = 'block';
  kittyImage.style.borderRadius = '50%';
  kittyImage.style.border = '3px solid white';
  
  // Create password input
  const passwordInput = document.createElement('input');
  passwordInput.type = 'password';
  passwordInput.placeholder = 'Enter admin password';
  passwordInput.style.width = '100%';
  passwordInput.style.padding = '0.75rem';
  passwordInput.style.borderRadius = '8px';
  passwordInput.style.border = 'none';
  passwordInput.style.marginBottom = '1rem';
  passwordInput.style.fontSize = '1rem';
  
  // Create buttons container
  const buttonsContainer = document.createElement('div');
  buttonsContainer.style.display = 'flex';
  buttonsContainer.style.gap = '1rem';
  
  // Create submit button
  const submitButton = document.createElement('button');
  submitButton.textContent = 'Access Admin';
  submitButton.style.flex = '1';
  submitButton.style.padding = '0.75rem';
  submitButton.style.borderRadius = '8px';
  submitButton.style.border = 'none';
  submitButton.style.background = '#ff3e6c';
  submitButton.style.color = 'white';
  submitButton.style.fontWeight = 'bold';
  submitButton.style.cursor = 'pointer';
  
  // Create cancel button
  const cancelButton = document.createElement('button');
  cancelButton.textContent = 'Cancel';
  cancelButton.style.flex = '1';
  cancelButton.style.padding = '0.75rem';
  cancelButton.style.borderRadius = '8px';
  cancelButton.style.border = 'none';
  cancelButton.style.background = 'rgba(255,255,255,0.2)';
  cancelButton.style.color = 'white';
  cancelButton.style.fontWeight = 'bold';
  cancelButton.style.cursor = 'pointer';
  
  // Add event listeners
  submitButton.addEventListener('click', () => {
    const password = passwordInput.value;
    if (password === ADMIN_PASSWORD) {
      enableAdminAccess();
      showNotification('Admin access granted!');
      document.body.removeChild(modalOverlay);
    } else {
      passwordInput.style.border = '2px solid red';
      passwordInput.value = '';
      passwordInput.placeholder = 'Incorrect password';
      
      // Shake animation
      modalContent.style.animation = 'shake 0.5s ease';
      setTimeout(() => {
        modalContent.style.animation = '';
      }, 500);
    }
  });
  
  cancelButton.addEventListener('click', () => {
    document.body.removeChild(modalOverlay);
  });
  
  // Allow Enter key to submit
  passwordInput.addEventListener('keyup', (event) => {
    if (event.key === 'Enter') {
      submitButton.click();
    }
  });
  
  // Assemble modal
  buttonsContainer.appendChild(submitButton);
  buttonsContainer.appendChild(cancelButton);
  
  modalContent.appendChild(modalHeader);
  modalContent.appendChild(kittyImage);
  modalContent.appendChild(passwordInput);
  modalContent.appendChild(buttonsContainer);
  
  modalOverlay.appendChild(modalContent);
  
  // Add to document
  document.body.appendChild(modalOverlay);
  
  // Focus password input
  setTimeout(() => {
    passwordInput.focus();
  }, 100);
  
  // Add shake keyframes if they don't exist
  if (!document.getElementById('admin-access-styles')) {
    const styleEl = document.createElement('style');
    styleEl.id = 'admin-access-styles';
    styleEl.textContent = `
      @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
      }
    `;
    document.head.appendChild(styleEl);
  }
}

// Enable admin access
function enableAdminAccess() {
  // Find admin button
  const adminBtn = document.getElementById('adminBtn');
  if (adminBtn) {
    adminBtn.classList.add('show');
    adminBtn.style.opacity = '1';
    adminBtn.style.pointerEvents = 'auto';
    adminBtn.style.display = 'block';
    console.log('Admin access: Admin button activated');
    
    // Store admin access in session
    try {
      sessionStorage.setItem('kdr_admin_access', 'true');
    } catch (e) {
      console.warn('Could not store admin access in session storage');
    }
  } else {
    console.warn('Admin access: Admin button not found');
  }
}

// Set up admin button functionality
function setupAdminButton() {
  const adminBtn = document.getElementById('adminBtn');
  if (adminBtn) {
    // Check if admin access was previously granted in this session
    try {
      if (sessionStorage.getItem('kdr_admin_access') === 'true') {
        enableAdminAccess();
      }
    } catch (e) {
      console.warn('Could not check session storage for admin access');
    }
  }
}

// Set up mutation observer to watch for kitty image being added to DOM
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Check if any of the added nodes is our kitty image
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // If this is an element, check if it's our kitty or contains our kitty
            const kittyImage = node.matches('.mascot-image[src*="zombie_kitty"], img[alt*="Zombie Kitty"]') ? 
              node : node.querySelector('.mascot-image[src*="zombie_kitty"], img[alt*="Zombie Kitty"]');
            
            if (kittyImage) {
              kittyImage.style.cursor = 'pointer';
              kittyImage.addEventListener('click', handleKittyClick);
              console.log('Admin access: Kitty click listener set up via mutation observer');
              observer.disconnect(); // Stop observing once we've found our kitty
            }
          }
        });
      }
    });
  });
  
  // Start observing the document with the configured parameters
  observer.observe(document.body, { childList: true, subtree: true });
  console.log('Admin access: Mutation observer set up');
}

// Helper function to show notifications
function showNotification(message) {
  // Check if there's a global showNotification function
  if (typeof window.showNotification === 'function') {
    window.showNotification(message);
    return;
  }
  
  // Otherwise create our own notification
  const notification = document.createElement('div');
  notification.textContent = message;
  notification.style.position = 'fixed';
  notification.style.bottom = '20px';
  notification.style.left = '50%';
  notification.style.transform = 'translateX(-50%)';
  notification.style.background = '#ffd166';
  notification.style.color = '#000';
  notification.style.padding = '1rem 1.5rem';
  notification.style.borderRadius = '8px';
  notification.style.fontWeight = '600';
  notification.style.zIndex = '2000';
  notification.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(-50%) translateY(20px)';
    notification.style.transition = 'all 0.3s ease';
    
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}