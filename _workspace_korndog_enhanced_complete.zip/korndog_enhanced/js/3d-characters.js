/**
 * KornDog Records - 3D Character Animation System
 * Creates lifelike 3D rendered characters with advanced animations
 */

class Character3DRenderer {
  constructor() {
    this.characters = {};
    this.mousePosition = { x: 0, y: 0 };
    this.windowCenter = {
      x: window.innerWidth / 2,
      y: window.innerHeight / 2
    };
    this.maxTilt = 15; // Maximum rotation in degrees
    this.initialized = false;
  }
  
  init() {
    if (this.initialized) return;
    
    // Find character containers
    const characterContainers = document.querySelectorAll('.character-container');
    
    characterContainers.forEach(container => {
      const id = container.id;
      const imageContainer = container.querySelector('.character-image');
      if (!imageContainer) return;
      
      // Get the original image
      const originalImg = imageContainer.querySelector('img');
      if (!originalImg) return;
      
      // Create 3D structure
      this.create3DCharacter(id, imageContainer, originalImg.src);
      
      // Store reference
      this.characters[id] = {
        container: container,
        element: imageContainer.querySelector('.character-image-3d'),
        layers: imageContainer.querySelectorAll('.character-layer'),
        shadow: container.querySelector('.character-shadow'),
        state: 'idle',
        lastInteraction: Date.now()
      };
    });
    
    // Add event listeners
    window.addEventListener('mousemove', this.handleMouseMove.bind(this));
    window.addEventListener('resize', this.handleResize.bind(this));
    
    // Start animation loop
    this.animate();
    
    this.initialized = true;
    console.log('3D Character Renderer initialized');
  }
  
  create3DCharacter(id, container, imageSrc) {
    // Clear container
    const originalHTML = container.innerHTML;
    container.innerHTML = '';
    
    // Create 3D structure
    const char3D = document.createElement('div');
    char3D.className = 'character-image-3d idle';
    
    // Create layers for parallax effect
    const layers = ['base', 'mid', 'top'];
    layers.forEach(layer => {
      const layerEl = document.createElement('div');
      layerEl.className = `character-layer layer-${layer}`;
      layerEl.style.backgroundImage = `url(${imageSrc})`;
      char3D.appendChild(layerEl);
    });
    
    // Add highlight effect
    const highlight = document.createElement('div');
    highlight.className = 'character-highlight';
    char3D.appendChild(highlight);
    
    // Add glow effect
    const glow = document.createElement('div');
    glow.className = 'character-glow';
    char3D.appendChild(glow);
    
    // Add to container
    container.appendChild(char3D);
    
    // Add shadow
    const shadow = document.createElement('div');
    shadow.className = 'character-shadow';
    container.appendChild(shadow);
    
    // Add particle container for special effects
    const particles = document.createElement('div');
    particles.className = 'character-particles';
    container.appendChild(particles);
    
    // Add click handler
    char3D.addEventListener('click', () => {
      this.triggerAnimation(id, 'excited');
      
      // Create particles on click
      this.createParticles(id, 10);
      
      // If character controller exists, trigger message
      if (window.characterController) {
        window.characterController.showMessage(id);
      }
    });
  }
  
  handleMouseMove(e) {
    this.mousePosition = {
      x: e.clientX,
      y: e.clientY
    };
    
    // Update window center if needed
    if (window.innerWidth !== this.windowCenter.x * 2 || 
        window.innerHeight !== this.windowCenter.y * 2) {
      this.handleResize();
    }
    
    // Apply parallax effect to characters
    Object.keys(this.characters).forEach(id => {
      const character = this.characters[id];
      if (!character.element) return;
      
      // Get character position
      const rect = character.element.getBoundingClientRect();
      const charCenter = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      };
      
      // Calculate distance from mouse
      const distX = this.mousePosition.x - charCenter.x;
      const distY = this.mousePosition.y - charCenter.y;
      
      // Calculate rotation based on mouse position
      const rotateY = (distX / window.innerWidth) * this.maxTilt;
      const rotateX = -(distY / window.innerHeight) * this.maxTilt;
      
      // Apply rotation if character is visible and in idle state
      if (character.state === 'idle' && this.isElementInViewport(character.element)) {
        character.element.style.transform = `rotateY(${rotateY}deg) rotateX(${rotateX}deg)`;
        
        // Apply parallax to layers
        if (character.layers) {
          character.layers.forEach((layer, index) => {
            const depth = (index + 1) * 5;
            layer.style.transform = `translateX(${distX / depth}px) translateY(${distY / depth}px) translateZ(${index * 10}px)`;
          });
        }
        
        // Update shadow position
        if (character.shadow) {
          character.shadow.style.transform = `translateX(${-rotateY * 0.5}px) rotateX(90deg)`;
        }
      }
    });
  }
  
  handleResize() {
    this.windowCenter = {
      x: window.innerWidth / 2,
      y: window.innerHeight / 2
    };
  }
  
  triggerAnimation(id, state) {
    const character = this.characters[id];
    if (!character || !character.element) return;
    
    // Remove all state classes
    character.element.classList.remove('idle', 'excited', 'thinking', 'greeting');
    
    // Add new state class
    character.element.classList.add(state);
    
    // Update state
    character.state = state;
    character.lastInteraction = Date.now();
    
    // Return to idle after animation completes
    const animationDurations = {
      excited: 1000,
      greeting: 1000,
      thinking: 2000
    };
    
    setTimeout(() => {
      if (character.element) {
        character.element.classList.remove(state);
        character.element.classList.add('idle');
        character.state = 'idle';
      }
    }, animationDurations[state] || 1000);
  }
  
  createParticles(id, count) {
    const character = this.characters[id];
    if (!character || !character.container) return;
    
    const particleContainer = character.container.querySelector('.character-particles');
    if (!particleContainer) return;
    
    // Clear existing particles
    particleContainer.innerHTML = '';
    
    // Create new particles
    for (let i = 0; i < count; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      
      // Random properties
      const size = Math.random() * 8 + 2;
      const startX = Math.random() * 100;
      const startY = Math.random() * 100;
      const angle = Math.random() * Math.PI * 2;
      const distance = Math.random() * 50 + 20;
      const duration = Math.random() * 1000 + 500;
      const delay = Math.random() * 200;
      
      // Set initial position
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      particle.style.left = `${startX}%`;
      particle.style.top = `${startY}%`;
      
      // Add to container
      particleContainer.appendChild(particle);
      
      // Animate
      setTimeout(() => {
        const endX = startX + Math.cos(angle) * distance;
        const endY = startY + Math.sin(angle) * distance;
        
        particle.style.transition = `all ${duration}ms ease-out`;
        particle.style.transform = `translate(${endX - startX}px, ${endY - startY}px)`;
        particle.style.opacity = '0';
        
        // Remove after animation
        setTimeout(() => {
          if (particleContainer.contains(particle)) {
            particleContainer.removeChild(particle);
          }
        }, duration);
      }, delay);
    }
  }
  
  animate() {
    // Check for idle characters to add random animations
    Object.keys(this.characters).forEach(id => {
      const character = this.characters[id];
      if (!character) return;
      
      // If character has been idle for a while, add random animation
      const idleTime = Date.now() - character.lastInteraction;
      if (character.state === 'idle' && idleTime > 10000 && Math.random() < 0.005) {
        const animations = ['thinking', 'greeting'];
        const randomAnimation = animations[Math.floor(Math.random() * animations.length)];
        this.triggerAnimation(id, randomAnimation);
      }
    });
    
    // Continue animation loop
    requestAnimationFrame(this.animate.bind(this));
  }
  
  isElementInViewport(el) {
    if (!el) return false;
    
    const rect = el.getBoundingClientRect();
    return (
      rect.top >= -rect.height &&
      rect.left >= -rect.width &&
      rect.bottom <= (window.innerHeight + rect.height) &&
      rect.right <= (window.innerWidth + rect.width)
    );
  }
}

// Initialize on document load
document.addEventListener('DOMContentLoaded', () => {
  // Create 3D renderer
  window.character3DRenderer = new Character3DRenderer();
  
  // Initialize after a short delay to ensure DOM is ready
  setTimeout(() => {
    window.character3DRenderer.init();
  }, 1000);
  
  // Hook into character controller if it exists
  if (window.characterController) {
    // Store original showCharacter method
    const originalShowCharacter = window.characterController.showCharacter;
    
    // Override with 3D version
    window.characterController.showCharacter = function(charKey) {
      // Call original method
      originalShowCharacter.call(window.characterController, charKey);
      
      // Add 3D greeting animation
      setTimeout(() => {
        if (window.character3DRenderer) {
          window.character3DRenderer.triggerAnimation(charKey, 'greeting');
        }
      }, 100);
    };
    
    // Store original showCartMessage method
    const originalShowCartMessage = window.characterController.showCartMessage;
    
    // Override with 3D version
    window.characterController.showCartMessage = function(item) {
      // Call original method
      originalShowCartMessage.call(window.characterController, item);
      
      // Add 3D excited animation
      const charKey = this.activeCharacter;
      if (charKey && window.character3DRenderer) {
        window.character3DRenderer.triggerAnimation(charKey, 'excited');
        window.character3DRenderer.createParticles(charKey, 15);
      }
    };
  }
});