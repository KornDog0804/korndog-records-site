/**
 * KornDog Records - Character Animation System
 * Brings Zombie Kitty and Chibi Kitty to life throughout the site
 */

// Character Animation Controller
class CharacterController {
  constructor() {
    // Character configurations
    this.characters = {
      zombieKitty: {
        name: 'Zombie Kitty',
        element: document.getElementById('zombieKitty'),
        bubbleElement: document.getElementById('zombieKittyBubble'),
        imagePath: 'images/chibi_kitty.png', // This is actually the white kitty (Zombie Kitty)
        position: { x: 20, y: 'auto' },
        section: 'vinyl',
        messages: [
          "Vinyl therapy in session! 🎵",
          "This record is to die for... literally!",
          "Spin that wax, human!",
          "I was listening to this album before I became undead...",
          "Nothing beats the warm sound of vinyl!",
          "This one's a killer track... trust me, I know killer!",
          "I've been collecting records for nine lifetimes!",
          "Add this to your cart or I'll haunt your turntable!",
          "This pressing is so fresh it woke me from the grave!",
          "Zombie approved vinyl selection!"
        ]
      },
      chibiKitty: {
        name: 'Chibi Kitty',
        element: document.getElementById('chibiKitty'),
        bubbleElement: document.getElementById('chibiKittyBubble'),
        imagePath: 'images/zombie_kitty.png', // This is actually the green kitty (Chibi Kitty)
        position: { x: 'auto', y: 20 },
        section: 'funkos',
        messages: [
          "Kawaii Funko alert! ✨",
          "This Funko is super cute, just like me!",
          "Collect them all, nya~!",
          "This would look perfect on your shelf!",
          "Funko-tastic choice!",
          "Chibi approved collectible!",
          "This Funko is rare, just like my green fur!",
          "Pop culture perfection in vinyl form!",
          "Your collection needs this cutie!",
          "Funko friends forever!"
        ]
      }
    };
    
    this.isInitialized = false;
    this.activeCharacter = null;
  }
  
  // Initialize character elements
  init() {
    if (this.isInitialized) return;
    
    // Create character elements if they don't exist
    Object.keys(this.characters).forEach(charKey => {
      const character = this.characters[charKey];
      
      if (!character.element) {
        // Create character container
        const charContainer = document.createElement('div');
        charContainer.id = charKey;
        charContainer.className = 'character-container';
        charContainer.style.position = 'fixed';
        charContainer.style.bottom = '20px';
        charContainer.style.zIndex = '1000';
        
        if (character.position.x === 'auto') {
          charContainer.style.right = '20px';
        } else {
          charContainer.style.left = character.position.x + 'px';
        }
        
        if (character.position.y === 'auto') {
          charContainer.style.bottom = '20px';
        } else {
          charContainer.style.bottom = character.position.y + 'px';
        }
        
        // Create character image
        const charImage = document.createElement('div');
        charImage.className = 'character-image';
        charImage.innerHTML = `<img src="${character.imagePath}" alt="${character.name}">`;
        
        // Create speech bubble
        const speechBubble = document.createElement('div');
        speechBubble.className = 'speech-bubble';
        speechBubble.id = `${charKey}Bubble`;
        speechBubble.style.display = 'none';
        
        // Add to container
        charContainer.appendChild(charImage);
        charContainer.appendChild(speechBubble);
        
        // Add to document
        document.body.appendChild(charContainer);
        
        // Update references
        character.element = charContainer;
        character.bubbleElement = speechBubble;
        
        // Add click event
        charImage.addEventListener('click', () => {
          this.showMessage(charKey);
        });
      }
      
      // Initially hide characters
      character.element.style.display = 'none';
    });
    
    // Listen for page changes
    document.addEventListener('pageChanged', (e) => {
      this.handlePageChange(e.detail.page);
    });
    
    this.isInitialized = true;
  }
  
  // Handle page changes to show relevant character
  handlePageChange(page) {
    // Hide all characters first
    Object.keys(this.characters).forEach(charKey => {
      const character = this.characters[charKey];
      character.element.style.display = 'none';
    });
    
    // Show relevant character based on page
    if (page === 'shop' || page === 'vinyl') {
      this.showCharacter('zombieKitty');
      this.activeCharacter = 'zombieKitty';
    } else if (page === 'funkos') {
      this.showCharacter('chibiKitty');
      this.activeCharacter = 'chibiKitty';
    } else if (page === 'collectibles') {
      // Show random character for collectibles
      const randomChar = Math.random() > 0.5 ? 'zombieKitty' : 'chibiKitty';
      this.showCharacter(randomChar);
      this.activeCharacter = randomChar;
    } else if (page === 'home') {
      // Show both characters on home page with animation
      setTimeout(() => {
        this.showCharacter('zombieKitty');
        setTimeout(() => {
          this.showMessage('zombieKitty', 'Welcome to KornDog Records!');
        }, 1000);
      }, 2000);
      
      setTimeout(() => {
        this.showCharacter('chibiKitty');
        setTimeout(() => {
          this.showMessage('chibiKitty', 'Check out our awesome collections!');
        }, 1000);
      }, 3500);
    }
  }
  
  // Show a character with animation
  showCharacter(charKey) {
    const character = this.characters[charKey];
    if (!character || !character.element) return;
    
    // Reset any existing animations
    character.element.style.animation = 'none';
    character.element.offsetHeight; // Trigger reflow
    
    // Show character with entrance animation
    character.element.style.display = 'block';
    character.element.style.animation = 'characterEntrance 0.8s cubic-bezier(0.17, 0.89, 0.32, 1.49)';
    
    // Add floating animation after entrance
    setTimeout(() => {
      character.element.classList.add('floating-animation');
    }, 800);
  }
  
  // Hide a character with animation
  hideCharacter(charKey) {
    const character = this.characters[charKey];
    if (!character || !character.element) return;
    
    // Exit animation
    character.element.style.animation = 'characterExit 0.5s ease-in forwards';
    
    // Hide after animation completes
    setTimeout(() => {
      character.element.style.display = 'none';
      character.element.style.animation = '';
      character.element.classList.remove('floating-animation');
    }, 500);
  }
  
  // Show a speech bubble message
  showMessage(charKey, customMessage = null) {
    const character = this.characters[charKey];
    if (!character || !character.bubbleElement) return;
    
    // Get message - either custom or random from character's messages
    const message = customMessage || character.messages[Math.floor(Math.random() * character.messages.length)];
    
    // Set message text
    character.bubbleElement.textContent = message;
    
    // Show bubble with animation
    character.bubbleElement.style.display = 'block';
    character.bubbleElement.style.animation = 'bubbleAppear 0.3s ease forwards';
    
    // Hide bubble after delay
    setTimeout(() => {
      character.bubbleElement.style.animation = 'bubbleFade 0.3s ease forwards';
      setTimeout(() => {
        character.bubbleElement.style.display = 'none';
      }, 300);
    }, 5000);
  }
  
  // Show message when item added to cart
  showCartMessage(item) {
    // Determine which character should respond based on item type
    let charKey = this.activeCharacter;
    
    // If we can determine item type more specifically, use appropriate character
    if (item.category === 'vinyl' || item.title.toLowerCase().includes('vinyl') || 
        item.title.toLowerCase().includes('record')) {
      charKey = 'zombieKitty';
    } else if (item.category === 'funko' || item.title.toLowerCase().includes('funko') || 
               item.title.toLowerCase().includes('pop')) {
      charKey = 'chibiKitty';
    }
    
    // Make sure character is visible
    this.showCharacter(charKey);
    
    // Show custom message about the item
    const customMessage = `${item.title} added to cart! Great choice!`;
    this.showMessage(charKey, customMessage);
    
    // Add bounce animation to character
    const character = this.characters[charKey];
    if (character && character.element) {
      character.element.classList.add('bounce-animation');
      setTimeout(() => {
        character.element.classList.remove('bounce-animation');
      }, 1000);
    }
  }
  
  // Show recommendation from character
  showRecommendation(items) {
    if (!this.activeCharacter || !items || items.length === 0) return;
    
    const character = this.characters[this.activeCharacter];
    if (!character) return;
    
    // Pick random item to recommend
    const item = items[Math.floor(Math.random() * items.length)];
    
    // Create recommendation message
    const messages = [
      `Check out ${item.title}! I think you'll love it!`,
      `Have you seen ${item.title} yet? It's one of my favorites!`,
      `${item.title} would be a perfect addition to your collection!`,
      `I personally recommend ${item.title}. It's amazing!`,
      `If I were you, I'd definitely grab ${item.title} before it's gone!`
    ];
    
    const message = messages[Math.floor(Math.random() * messages.length)];
    
    // Show recommendation
    this.showMessage(this.activeCharacter, message);
  }
  
  // Show idle animation and message after period of inactivity
  startIdleAnimation() {
    if (!this.activeCharacter) return;
    
    const character = this.characters[this.activeCharacter];
    if (!character || !character.element) return;
    
    // Add shake animation
    character.element.classList.add('shake-animation');
    
    // Show attention-grabbing message
    const idleMessages = [
      "Hey! I'm still here to help!",
      "Need any recommendations?",
      "Don't forget to check out our new arrivals!",
      "Psst! Looking for something specific?",
      "I can help you find the perfect item!"
    ];
    
    const message = idleMessages[Math.floor(Math.random() * idleMessages.length)];
    this.showMessage(this.activeCharacter, message);
    
    // Remove animation after a moment
    setTimeout(() => {
      character.element.classList.remove('shake-animation');
    }, 1000);
  }
}

// Character CSS Styles
function injectCharacterStyles() {
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    .character-container {
      position: fixed;
      z-index: 1000;
      transition: all 0.3s ease;
    }
    
    .character-image {
      width: 120px;
      height: 120px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }
    
    .character-image img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
    
    .character-image:hover {
      transform: scale(1.1);
    }
    
    .speech-bubble {
      position: absolute;
      background: white;
      border: 3px solid #333;
      border-radius: 20px;
      padding: 15px;
      max-width: 250px;
      color: #333;
      font-weight: 700;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
      z-index: 1001;
    }
    
    #zombieKittyBubble {
      bottom: 100%;
      left: 50%;
      transform: translateX(-50%);
      margin-bottom: 15px;
    }
    
    #zombieKittyBubble:after {
      content: '';
      position: absolute;
      bottom: -15px;
      left: 50%;
      border: 15px solid transparent;
      border-top-color: white;
      border-bottom: 0;
      margin-left: -15px;
    }
    
    #zombieKittyBubble:before {
      content: '';
      position: absolute;
      bottom: -18px;
      left: 50%;
      border: 18px solid transparent;
      border-top-color: #333;
      border-bottom: 0;
      margin-left: -18px;
    }
    
    #chibiKittyBubble {
      bottom: 100%;
      right: 50%;
      transform: translateX(50%);
      margin-bottom: 15px;
    }
    
    #chibiKittyBubble:after {
      content: '';
      position: absolute;
      bottom: -15px;
      right: 30%;
      border: 15px solid transparent;
      border-top-color: white;
      border-bottom: 0;
    }
    
    #chibiKittyBubble:before {
      content: '';
      position: absolute;
      bottom: -18px;
      right: 30%;
      border: 18px solid transparent;
      border-top-color: #333;
      border-bottom: 0;
    }
    
    /* Animations */
    @keyframes characterEntrance {
      0% { transform: translateY(100px); opacity: 0; }
      70% { transform: translateY(-20px); }
      100% { transform: translateY(0); opacity: 1; }
    }
    
    @keyframes characterExit {
      0% { transform: translateY(0); opacity: 1; }
      100% { transform: translateY(100px); opacity: 0; }
    }
    
    @keyframes bubbleAppear {
      0% { transform: scale(0); opacity: 0; }
      70% { transform: scale(1.1); }
      100% { transform: scale(1); opacity: 1; }
    }
    
    @keyframes bubbleFade {
      0% { transform: scale(1); opacity: 1; }
      100% { transform: scale(0.8); opacity: 0; }
    }
    
    .floating-animation {
      animation: float 3s ease-in-out infinite;
    }
    
    @keyframes float {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
      100% { transform: translateY(0px); }
    }
    
    .bounce-animation {
      animation: bounce 1s ease;
    }
    
    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
      40% { transform: translateY(-20px); }
      60% { transform: translateY(-10px); }
    }
    
    .shake-animation {
      animation: shake 0.5s ease-in-out;
    }
    
    @keyframes shake {
      0% { transform: rotate(0deg); }
      25% { transform: rotate(5deg); }
      50% { transform: rotate(0deg); }
      75% { transform: rotate(-5deg); }
      100% { transform: rotate(0deg); }
    }
  `;
  
  document.head.appendChild(styleEl);
}

// Initialize character system
document.addEventListener('DOMContentLoaded', () => {
  // Inject character styles
  injectCharacterStyles();
  
  // Create character controller
  window.characterController = new CharacterController();
  window.characterController.init();
  
  // Hook into page navigation
  const originalShowPage = window.showPage;
  window.showPage = function(pageId) {
    originalShowPage(pageId);
    
    // Notify character controller of page change
    const event = new CustomEvent('pageChanged', { 
      detail: { page: pageId } 
    });
    document.dispatchEvent(event);
  };
  
  // Hook into add to cart function
  const originalAddToCart = window.addToCart;
  window.addToCart = function(item, qty = 1) {
    originalAddToCart(item, qty);
    
    // Notify character controller of cart addition
    if (window.characterController) {
      window.characterController.showCartMessage(item);
    }
  };
  
  // Set up idle animation timer
  let idleTimer;
  function resetIdleTimer() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      if (window.characterController) {
        window.characterController.startIdleAnimation();
      }
    }, 60000); // 1 minute of inactivity
  }
  
  // Reset idle timer on user interaction
  ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart'].forEach(evt => {
    document.addEventListener(evt, resetIdleTimer, true);
  });
  
  // Start idle timer
  resetIdleTimer();
  
  // Show recommendations periodically
  setInterval(() => {
    if (window.characterController && window.state && window.state.content) {
      // Get items from current page
      let items = [];
      const currentPage = window.state.currentPage;
      
      if (currentPage === 'shop' || currentPage === 'vinyl') {
        const sect = window.state.content.sections || [];
        items = (sect.find(s => /kitt/i.test(s.title)) || {}).items || [];
      } else if (currentPage === 'funkos') {
        const sect = window.state.content.sections || [];
        items = (sect.find(s => /funko/i.test(s.title)) || {}).items || [];
      } else if (currentPage === 'collectibles') {
        const sect = window.state.content.sections || [];
        items = (sect.find(s => /collect/i.test(s.title)) || {}).items || [];
      }
      
      if (items.length > 0) {
        window.characterController.showRecommendation(items);
      }
    }
  }, 120000); // Show recommendation every 2 minutes
});