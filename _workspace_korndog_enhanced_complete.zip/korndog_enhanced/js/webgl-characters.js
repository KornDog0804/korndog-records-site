/**
 * KornDog Records - WebGL Character Effects
 * Adds advanced 3D rendering effects using WebGL
 */

class WebGLCharacterEffects {
  constructor() {
    this.canvas = null;
    this.gl = null;
    this.program = null;
    this.characters = {};
    this.textures = {};
    this.initialized = false;
  }
  
  init() {
    if (this.initialized) return;
    
    // Create canvas for WebGL rendering
    this.canvas = document.createElement('canvas');
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    this.canvas.style.position = 'fixed';
    this.canvas.style.top = '0';
    this.canvas.style.left = '0';
    this.canvas.style.pointerEvents = 'none';
    this.canvas.style.zIndex = '9999';
    document.body.appendChild(this.canvas);
    
    // Initialize WebGL
    try {
      this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');
      
      if (!this.gl) {
        console.warn('WebGL not supported, falling back to CSS 3D effects');
        return;
      }
      
      // Set up shaders
      this.setupShaders();
      
      // Load character textures
      this.loadTextures();
      
      // Set up resize handler
      window.addEventListener('resize', this.handleResize.bind(this));
      
      this.initialized = true;
      console.log('WebGL Character Effects initialized');
      
      // Start render loop
      this.render();
    } catch (e) {
      console.error('Error initializing WebGL:', e);
    }
  }
  
  setupShaders() {
    // Vertex shader program
    const vsSource = `
      attribute vec4 aVertexPosition;
      attribute vec2 aTextureCoord;
      
      uniform mat4 uModelViewMatrix;
      uniform mat4 uProjectionMatrix;
      
      varying highp vec2 vTextureCoord;
      
      void main(void) {
        gl_Position = uProjectionMatrix * uModelViewMatrix * aVertexPosition;
        vTextureCoord = aTextureCoord;
      }
    `;
    
    // Fragment shader program
    const fsSource = `
      varying highp vec2 vTextureCoord;
      
      uniform sampler2D uSampler;
      uniform highp float uTime;
      uniform highp vec2 uResolution;
      uniform highp vec2 uMouse;
      
      void main(void) {
        highp vec2 uv = vTextureCoord;
        
        // Distortion effect
        highp float distortion = sin(uv.y * 10.0 + uTime) * 0.01;
        uv.x += distortion;
        
        // Mouse interaction
        highp vec2 mousePos = uMouse / uResolution;
        highp float mouseDist = distance(uv, mousePos);
        highp float mouseEffect = smoothstep(0.3, 0.0, mouseDist) * 0.1;
        uv += (uv - mousePos) * mouseEffect;
        
        // Glow effect
        highp vec4 texColor = texture2D(uSampler, uv);
        highp float glow = sin(uTime * 2.0) * 0.1 + 0.1;
        
        // Apply glow to edges
        highp float edgeGlow = smoothstep(0.4, 0.5, length(uv - 0.5)) * glow;
        texColor.rgb += vec3(0.1, 0.2, 0.3) * edgeGlow;
        
        gl_FragColor = texColor;
      }
    `;
    
    // Create shader program
    const vertexShader = this.loadShader(this.gl.VERTEX_SHADER, vsSource);
    const fragmentShader = this.loadShader(this.gl.FRAGMENT_SHADER, fsSource);
    
    // Create the shader program
    this.program = this.gl.createProgram();
    this.gl.attachShader(this.program, vertexShader);
    this.gl.attachShader(this.program, fragmentShader);
    this.gl.linkProgram(this.program);
    
    // Check if program linked successfully
    if (!this.gl.getProgramParameter(this.program, this.gl.LINK_STATUS)) {
      console.error('Unable to initialize the shader program: ' + this.gl.getProgramInfoLog(this.program));
      return;
    }
    
    // Store program info
    this.programInfo = {
      program: this.program,
      attribLocations: {
        vertexPosition: this.gl.getAttribLocation(this.program, 'aVertexPosition'),
        textureCoord: this.gl.getAttribLocation(this.program, 'aTextureCoord'),
      },
      uniformLocations: {
        projectionMatrix: this.gl.getUniformLocation(this.program, 'uProjectionMatrix'),
        modelViewMatrix: this.gl.getUniformLocation(this.program, 'uModelViewMatrix'),
        sampler: this.gl.getUniformLocation(this.program, 'uSampler'),
        time: this.gl.getUniformLocation(this.program, 'uTime'),
        resolution: this.gl.getUniformLocation(this.program, 'uResolution'),
        mouse: this.gl.getUniformLocation(this.program, 'uMouse'),
      },
    };
    
    // Create buffers
    this.initBuffers();
  }
  
  loadShader(type, source) {
    const shader = this.gl.createShader(type);
    this.gl.shaderSource(shader, source);
    this.gl.compileShader(shader);
    
    // Check if compilation was successful
    if (!this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS)) {
      console.error('An error occurred compiling the shaders: ' + this.gl.getShaderInfoLog(shader));
      this.gl.deleteShader(shader);
      return null;
    }
    
    return shader;
  }
  
  initBuffers() {
    // Create position buffer for a quad
    const positionBuffer = this.gl.createBuffer();
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, positionBuffer);
    
    // Quad vertices (2 triangles)
    const positions = [
      -1.0, -1.0,  0.0,
       1.0, -1.0,  0.0,
       1.0,  1.0,  0.0,
      -1.0,  1.0,  0.0,
    ];
    
    this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(positions), this.gl.STATIC_DRAW);
    
    // Create texture coordinate buffer
    const textureCoordBuffer = this.gl.createBuffer();
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, textureCoordBuffer);
    
    // Texture coordinates
    const textureCoordinates = [
      0.0, 0.0,
      1.0, 0.0,
      1.0, 1.0,
      0.0, 1.0,
    ];
    
    this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(textureCoordinates), this.gl.STATIC_DRAW);
    
    // Create index buffer
    const indexBuffer = this.gl.createBuffer();
    this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    
    // Indices for the triangles
    const indices = [
      0, 1, 2,
      0, 2, 3,
    ];
    
    this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), this.gl.STATIC_DRAW);
    
    // Store buffers
    this.buffers = {
      position: positionBuffer,
      textureCoord: textureCoordBuffer,
      indices: indexBuffer,
    };
  }
  
  loadTextures() {
    // Load character textures
    this.loadCharacterTexture('zombieKitty', 'images/chibi_kitty.png'); // White Zombie Kitty
    this.loadCharacterTexture('chibiKitty', 'images/zombie_kitty.png'); // Green Chibi Kitty
  }
  
  loadCharacterTexture(id, url) {
    const texture = this.gl.createTexture();
    this.gl.bindTexture(this.gl.TEXTURE_2D, texture);
    
    // Fill with a placeholder color until the image loads
    const level = 0;
    const internalFormat = this.gl.RGBA;
    const width = 1;
    const height = 1;
    const border = 0;
    const srcFormat = this.gl.RGBA;
    const srcType = this.gl.UNSIGNED_BYTE;
    const pixel = new Uint8Array([200, 200, 255, 255]); // Light blue placeholder
    this.gl.texImage2D(this.gl.TEXTURE_2D, level, internalFormat,
                  width, height, border, srcFormat, srcType,
                  pixel);
    
    // Load the image
    const image = new Image();
    image.onload = () => {
      this.gl.bindTexture(this.gl.TEXTURE_2D, texture);
      this.gl.texImage2D(this.gl.TEXTURE_2D, level, internalFormat,
                    srcFormat, srcType, image);
      
      // Generate mipmaps
      if (this.isPowerOf2(image.width) && this.isPowerOf2(image.height)) {
        this.gl.generateMipmap(this.gl.TEXTURE_2D);
      } else {
        // No mipmaps for non-power-of-2 textures
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_S, this.gl.CLAMP_TO_EDGE);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_T, this.gl.CLAMP_TO_EDGE);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.LINEAR);
      }
      
      console.log(`Loaded texture for ${id}`);
    };
    image.src = url;
    
    // Store texture
    this.textures[id] = texture;
  }
  
  isPowerOf2(value) {
    return (value & (value - 1)) === 0;
  }
  
  handleResize() {
    // Update canvas size
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    
    // Update WebGL viewport
    this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
  }
  
  applyEffectToCharacter(id) {
    const character = document.getElementById(id);
    if (!character) return;
    
    // Get character position and size
    const rect = character.getBoundingClientRect();
    
    // Check if character is visible
    if (rect.bottom < 0 || rect.top > window.innerHeight ||
        rect.right < 0 || rect.left > window.innerWidth) {
      return; // Character is off-screen
    }
    
    // Store character info for rendering
    this.characters[id] = {
      rect: rect,
      texture: this.textures[id],
      lastUpdate: Date.now()
    };
  }
  
  render() {
    // Continue render loop
    requestAnimationFrame(this.render.bind(this));
    
    if (!this.initialized) return;
    
    // Clear canvas
    this.gl.clearColor(0.0, 0.0, 0.0, 0.0);
    this.gl.clear(this.gl.COLOR_BUFFER_BIT);
    
    // Update character effects
    if (window.characterController) {
      const activeChar = window.characterController.activeCharacter;
      if (activeChar) {
        this.applyEffectToCharacter(activeChar);
      }
    }
    
    // Render each character with WebGL effects
    Object.keys(this.characters).forEach(id => {
      const character = this.characters[id];
      if (!character || !character.texture) return;
      
      // Skip if character was updated too long ago (no longer visible)
      if (Date.now() - character.lastUpdate > 1000) {
        delete this.characters[id];
        return;
      }
      
      this.renderCharacter(id, character);
    });
  }
  
  renderCharacter(id, character) {
    // Set up viewport for this character
    const rect = character.rect;
    
    // Convert to WebGL coordinates (0,0 is bottom left in WebGL)
    const left = rect.left;
    const bottom = this.canvas.height - rect.bottom;
    const width = rect.width;
    const height = rect.height;
    
    this.gl.viewport(left, bottom, width, height);
    
    // Set up shader program
    this.gl.useProgram(this.programInfo.program);
    
    // Set uniforms
    const projectionMatrix = this.createOrthographicMatrix(-1, 1, -1, 1, -1, 1);
    const modelViewMatrix = this.createIdentityMatrix();
    
    this.gl.uniformMatrix4fv(
      this.programInfo.uniformLocations.projectionMatrix,
      false,
      projectionMatrix);
    this.gl.uniformMatrix4fv(
      this.programInfo.uniformLocations.modelViewMatrix,
      false,
      modelViewMatrix);
    
    // Set time uniform
    this.gl.uniform1f(
      this.programInfo.uniformLocations.time,
      performance.now() / 1000);
    
    // Set resolution uniform
    this.gl.uniform2f(
      this.programInfo.uniformLocations.resolution,
      this.canvas.width, this.canvas.height);
    
    // Set mouse position uniform
    const mouseX = window.mouseX || 0;
    const mouseY = window.mouseY || 0;
    this.gl.uniform2f(
      this.programInfo.uniformLocations.mouse,
      mouseX, mouseY);
    
    // Bind position buffer
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.buffers.position);
    this.gl.vertexAttribPointer(
      this.programInfo.attribLocations.vertexPosition,
      3, // numComponents
      this.gl.FLOAT, // type
      false, // normalize
      0, // stride
      0); // offset
    this.gl.enableVertexAttribArray(this.programInfo.attribLocations.vertexPosition);
    
    // Bind texture coordinate buffer
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.buffers.textureCoord);
    this.gl.vertexAttribPointer(
      this.programInfo.attribLocations.textureCoord,
      2, // numComponents
      this.gl.FLOAT, // type
      false, // normalize
      0, // stride
      0); // offset
    this.gl.enableVertexAttribArray(this.programInfo.attribLocations.textureCoord);
    
    // Bind indices
    this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.buffers.indices);
    
    // Set texture
    this.gl.activeTexture(this.gl.TEXTURE0);
    this.gl.bindTexture(this.gl.TEXTURE_2D, character.texture);
    this.gl.uniform1i(this.programInfo.uniformLocations.sampler, 0);
    
    // Draw
    this.gl.drawElements(
      this.gl.TRIANGLES,
      6, // vertexCount
      this.gl.UNSIGNED_SHORT, // type
      0); // offset
  }
  
  createOrthographicMatrix(left, right, bottom, top, near, far) {
    // Create orthographic projection matrix
    const lr = 1 / (left - right);
    const bt = 1 / (bottom - top);
    const nf = 1 / (near - far);
    
    return [
      -2 * lr, 0, 0, 0,
      0, -2 * bt, 0, 0,
      0, 0, 2 * nf, 0,
      (left + right) * lr, (top + bottom) * bt, (far + near) * nf, 1
    ];
  }
  
  createIdentityMatrix() {
    return [
      1, 0, 0, 0,
      0, 1, 0, 0,
      0, 0, 1, 0,
      0, 0, 0, 1
    ];
  }
}

// Track mouse position for WebGL effects
window.mouseX = 0;
window.mouseY = 0;
document.addEventListener('mousemove', (e) => {
  window.mouseX = e.clientX;
  window.mouseY = e.clientY;
});

// Initialize WebGL effects after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Initialize after a delay to ensure other systems are ready
  setTimeout(() => {
    window.webglCharacterEffects = new WebGLCharacterEffects();
    window.webglCharacterEffects.init();
  }, 2000);
});