/**
 * KornDog Records - Enhanced JavaScript
 * This file contains additional functionality for the enhanced KornDog Records site
 */

// ======= ADVANCED ANIMATIONS =======

// Vinyl Record Animation Controller
class VinylAnimation {
  constructor() {
    this.vinylElements = document.querySelectorAll('.vinyl-record, .vinyl-disc');
    this.isPlaying = false;
    this.rotationSpeed = 2; // seconds per rotation
  }
  
  play() {
    if (this.isPlaying) return;
    
    this.vinylElements.forEach(vinyl => {
      vinyl.style.animation = `spin ${this.rotationSpeed}s linear infinite`;
    });
    
    this.isPlaying = true;
  }
  
  pause() {
    if (!this.isPlaying) return;
    
    this.vinylElements.forEach(vinyl => {
      // Get current rotation and freeze there
      const computedStyle = window.getComputedStyle(vinyl);
      const transform = computedStyle.getPropertyValue('transform');
      vinyl.style.animation = 'none';
      vinyl.style.transform = transform;
    });
    
    this.isPlaying = false;
  }
  
  setSpeed(speed) {
    this.rotationSpeed = speed;
    if (this.isPlaying) {
      this.vinylElements.forEach(vinyl => {
        vinyl.style.animation = `spin ${this.rotationSpeed}s linear infinite`;
      });
    }
  }
}

// Audio Visualizer
class AudioVisualizer {
  constructor(containerId, barCount = 10) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;
    
    this.barCount = barCount;
    this.bars = [];
    this.isActive = false;
    
    this.createBars();
  }
  
  createBars() {
    this.container.innerHTML = '';
    
    for (let i = 0; i < this.barCount; i++) {
      const bar = document.createElement('div');
      bar.className = 'visualizer-bar';
      this.container.appendChild(bar);
      this.bars.push(bar);
    }
  }
  
  start() {
    if (this.isActive) return;
    this.isActive = true;
    this.animate();
  }
  
  stop() {
    this.isActive = false;
  }
  
  animate() {
    if (!this.isActive) return;
    
    this.bars.forEach(bar => {
      const height = Math.floor(Math.random() * 40) + 10;
      bar.style.height = `${height}px`;
    });
    
    setTimeout(() => this.animate(), 100);
  }
}

// Particle System
class ParticleSystem {
  constructor(containerId, count = 50) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;
    
    this.count = count;
    this.particles = [];
    
    this.createParticles();
  }
  
  createParticles() {
    this.container.innerHTML = '';
    
    for (let i = 0; i < this.count; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      
      // Random properties
      const size = Math.random() * 5 + 2;
      const posX = Math.random() * 100;
      const posY = Math.random() * 100;
      const opacity = Math.random() * 0.5 + 0.1;
      const duration = Math.random() * 20 + 10;
      const delay = Math.random() * 5;
      
      // Apply styles
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      particle.style.left = `${posX}%`;
      particle.style.top = `${posY}%`;
      particle.style.opacity = opacity;
      particle.style.animation = `float ${duration}s ease-in-out ${delay}s infinite alternate`;
      
      this.container.appendChild(particle);
      this.particles.push(particle);
    }
  }
}

// ======= INTERACTIVE FEATURES =======

// Product Filter System
class ProductFilter {
  constructor(gridId, filterBtnsSelector) {
    this.grid = document.getElementById(gridId);
    this.filterBtns = document.querySelectorAll(filterBtnsSelector);
    
    if (!this.grid || !this.filterBtns.length) return;
    
    this.initEvents();
  }
  
  initEvents() {
    this.filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Update active button
        this.filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // Apply filter
        const filter = btn.getAttribute('data-filter');
        this.applyFilter(filter);
      });
    });
  }
  
  applyFilter(filter) {
    const items = this.grid.querySelectorAll('.card');
    
    items.forEach(item => {
      if (filter === 'all') {
        item.style.display = '';
        return;
      }
      
      // Check if item has the filter class or attribute
      const hasFilter = item.classList.contains(filter) || 
                        item.getAttribute('data-category') === filter ||
                        (filter === 'new' && item.querySelector('.product-tag.new')) ||
                        (filter === 'rare' && item.querySelector('.product-tag.rare')) ||
                        (filter === 'sale' && item.querySelector('.product-tag.sale'));
      
      item.style.display = hasFilter ? '' : 'none';
    });
  }
}

// Product Sorter
class ProductSorter {
  constructor(gridId, sortSelectId) {
    this.grid = document.getElementById(gridId);
    this.sortSelect = document.getElementById(sortSelectId);
    
    if (!this.grid || !this.sortSelect) return;
    
    this.initEvents();
  }
  
  initEvents() {
    this.sortSelect.addEventListener('change', () => {
      const sortBy = this.sortSelect.value;
      this.applySort(sortBy);
    });
  }
  
  applySort(sortBy) {
    const items = Array.from(this.grid.querySelectorAll('.card'));
    
    items.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return this.getPriceFromCard(a) - this.getPriceFromCard(b);
        case 'price-high':
          return this.getPriceFromCard(b) - this.getPriceFromCard(a);
        case 'newest':
          return b.querySelector('.product-tag.new') ? 1 : -1;
        default: // featured
          return 0;
      }
    });
    
    // Re-append items in new order
    items.forEach(item => this.grid.appendChild(item));
  }
  
  getPriceFromCard(card) {
    const priceEl = card.querySelector('.price');
    if (!priceEl) return 0;
    
    const priceText = priceEl.textContent;
    return parseFloat(priceText.replace(/[^0-9.-]+/g, '')) || 0;
  }
}

// Wishlist Manager
class WishlistManager {
  constructor() {
    this.wishlist = JSON.parse(localStorage.getItem('kdr_wishlist') || '[]');
    this.initEvents();
  }
  
  initEvents() {
    // Update wishlist buttons on page load
    document.addEventListener('DOMContentLoaded', () => {
      this.updateWishlistButtons();
    });
  }
  
  updateWishlistButtons() {
    const wishlistBtns = document.querySelectorAll('.wishlist-btn');
    
    wishlistBtns.forEach(btn => {
      const card = btn.closest('.card');
      if (!card) return;
      
      const title = card.querySelector('.item-title')?.textContent;
      const isInWishlist = this.isInWishlist(title);
      
      const icon = btn.querySelector('i');
      if (isInWishlist) {
        icon.classList.remove('far');
        icon.classList.add('fas');
      } else {
        icon.classList.remove('fas');
        icon.classList.add('far');
      }
    });
  }
  
  toggleWishlist(item) {
    const index = this.wishlist.findIndex(i => i.title === item.title);
    
    if (index >= 0) {
      // Remove from wishlist
      this.wishlist.splice(index, 1);
    } else {
      // Add to wishlist
      this.wishlist.push({
        title: item.title,
        price: item.price,
        image: item.image
      });
    }
    
    // Save to localStorage
    localStorage.setItem('kdr_wishlist', JSON.stringify(this.wishlist));
    
    // Update UI
    this.updateWishlistButtons();
    
    return index < 0; // Return true if added, false if removed
  }
  
  isInWishlist(title) {
    return this.wishlist.some(item => item.title === title);
  }
  
  getWishlist() {
    return this.wishlist;
  }
}

// Search Functionality
class ProductSearch {
  constructor(inputId, resultsContainerId) {
    this.input = document.getElementById(inputId);
    this.resultsContainer = document.getElementById(resultsContainerId);
    
    if (!this.input || !this.resultsContainer) return;
    
    this.allProducts = [];
    this.initEvents();
  }
  
  initEvents() {
    this.input.addEventListener('input', () => {
      const query = this.input.value.trim().toLowerCase();
      
      if (query.length < 2) {
        this.resultsContainer.innerHTML = '';
        this.resultsContainer.style.display = 'none';
        return;
      }
      
      this.search(query);
    });
    
    // Close search results when clicking outside
    document.addEventListener('click', (e) => {
      if (!this.input.contains(e.target) && !this.resultsContainer.contains(e.target)) {
        this.resultsContainer.style.display = 'none';
      }
    });
  }
  
  setProducts(products) {
    this.allProducts = products;
  }
  
  search(query) {
    const results = this.allProducts.filter(product => {
      return product.title.toLowerCase().includes(query) || 
             (product.description && product.description.toLowerCase().includes(query));
    });
    
    this.displayResults(results);
  }
  
  displayResults(results) {
    if (results.length === 0) {
      this.resultsContainer.innerHTML = '<div class="search-no-results">No products found</div>';
    } else {
      this.resultsContainer.innerHTML = results.map(product => `
        <div class="search-result-item" data-id="${product.id || product.title}">
          <img src="${product.image}" alt="${product.title}">
          <div class="search-result-info">
            <div class="search-result-title">${product.title}</div>
            <div class="search-result-price">${formatPrice(product.price)}</div>
          </div>
        </div>
      `).join('');
      
      // Add click event to results
      const resultItems = this.resultsContainer.querySelectorAll('.search-result-item');
      resultItems.forEach(item => {
        item.addEventListener('click', () => {
          const id = item.getAttribute('data-id');
          const product = this.allProducts.find(p => (p.id || p.title) === id);
          if (product) {
            showQuickView(product);
            this.resultsContainer.style.display = 'none';
            this.input.value = '';
          }
        });
      });
    }
    
    this.resultsContainer.style.display = 'block';
  }
}

// Recently Viewed Products
class RecentlyViewed {
  constructor(containerId, maxItems = 4) {
    this.container = document.getElementById(containerId);
    this.maxItems = maxItems;
    this.recentItems = JSON.parse(localStorage.getItem('kdr_recent_viewed') || '[]');
    
    if (!this.container) return;
  }
  
  addItem(item) {
    // Remove if already exists
    const existingIndex = this.recentItems.findIndex(i => (i.id || i.title) === (item.id || item.title));
    if (existingIndex >= 0) {
      this.recentItems.splice(existingIndex, 1);
    }
    
    // Add to front of array
    this.recentItems.unshift({
      id: item.id || item.title,
      title: item.title,
      price: item.price,
      image: item.image
    });
    
    // Limit array size
    if (this.recentItems.length > this.maxItems) {
      this.recentItems = this.recentItems.slice(0, this.maxItems);
    }
    
    // Save to localStorage
    localStorage.setItem('kdr_recent_viewed', JSON.stringify(this.recentItems));
    
    // Update UI
    this.render();
  }
  
  render() {
    if (!this.container || this.recentItems.length === 0) return;
    
    this.container.innerHTML = `
      <h3>Recently Viewed</h3>
      <div class="recent-items">
        ${this.recentItems.map(item => `
          <div class="recent-item" data-id="${item.id}">
            <img src="${item.image}" alt="${item.title}">
            <div class="recent-item-title">${item.title}</div>
            <div class="recent-item-price">${formatPrice(item.price)}</div>
          </div>
        `).join('')}
      </div>
    `;
    
    // Add click events
    const items = this.container.querySelectorAll('.recent-item');
    items.forEach(item => {
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-id');
        const product = this.recentItems.find(p => p.id === id);
        if (product) {
          showQuickView(product);
        }
      });
    });
  }
}

// Newsletter Popup
class NewsletterPopup {
  constructor(popupId) {
    this.popup = document.getElementById(popupId);
    if (!this.popup) return;
    
    this.hasSubscribed = localStorage.getItem('kdr_newsletter_subscribed') === 'true';
    this.hasClosedPopup = localStorage.getItem('kdr_newsletter_closed') === 'true';
    
    this.initEvents();
  }
  
  initEvents() {
    // Show popup after delay if not subscribed or closed before
    if (!this.hasSubscribed && !this.hasClosedPopup) {
      setTimeout(() => this.show(), 30000); // 30 seconds
    }
    
    // Close button
    const closeBtn = this.popup.querySelector('.newsletter-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        this.close();
        localStorage.setItem('kdr_newsletter_closed', 'true');
      });
    }
    
    // Form submission
    const form = this.popup.querySelector('form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.subscribe();
      });
    }
  }
  
  show() {
    this.popup.classList.add('active');
  }
  
  close() {
    this.popup.classList.remove('active');
  }
  
  subscribe() {
    // Here you would normally send the subscription to your backend
    localStorage.setItem('kdr_newsletter_subscribed', 'true');
    this.hasSubscribed = true;
    
    // Show success message
    const form = this.popup.querySelector('form');
    const successMsg = this.popup.querySelector('.newsletter-success');
    
    if (form && successMsg) {
      form.style.display = 'none';
      successMsg.style.display = 'block';
      
      // Close after delay
      setTimeout(() => this.close(), 3000);
    } else {
      this.close();
    }
  }
}

// Product Recommendations
class ProductRecommendations {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;
    
    this.allProducts = [];
  }
  
  setProducts(products) {
    this.allProducts = products;
  }
  
  getRecommendationsForProduct(product, count = 4) {
    // Simple recommendation algorithm based on similar titles or categories
    const recommendations = this.allProducts.filter(p => {
      // Don't recommend the same product
      if ((p.id || p.title) === (product.id || product.title)) return false;
      
      // Check for similar category or title words
      const productTitle = product.title.toLowerCase();
      const pTitle = p.title.toLowerCase();
      
      // Check if they share any words
      const productWords = productTitle.split(' ');
      const pWords = pTitle.split(' ');
      
      return productWords.some(word => pWords.includes(word));
    });
    
    // If not enough recommendations, add random products
    if (recommendations.length < count) {
      const remaining = count - recommendations.length;
      const randomProducts = this.allProducts
        .filter(p => (p.id || p.title) !== (product.id || product.title) && !recommendations.includes(p))
        .sort(() => 0.5 - Math.random())
        .slice(0, remaining);
      
      recommendations.push(...randomProducts);
    }
    
    return recommendations.slice(0, count);
  }
  
  render(product) {
    if (!this.container || !product) return;
    
    const recommendations = this.getRecommendationsForProduct(product);
    
    if (recommendations.length === 0) {
      this.container.style.display = 'none';
      return;
    }
    
    this.container.innerHTML = `
      <h3>You Might Also Like</h3>
      <div class="recommendations-grid">
        ${recommendations.map(item => `
          <div class="recommendation-item" data-id="${item.id || item.title}">
            <img src="${item.image}" alt="${item.title}">
            <div class="recommendation-title">${item.title}</div>
            <div class="recommendation-price">${formatPrice(item.price)}</div>
          </div>
        `).join('')}
      </div>
    `;
    
    // Add click events
    const items = this.container.querySelectorAll('.recommendation-item');
    items.forEach(item => {
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-id');
        const recommendedProduct = this.allProducts.find(p => (p.id || p.title) === id);
        if (recommendedProduct) {
          showQuickView(recommendedProduct);
        }
      });
    });
    
    this.container.style.display = 'block';
  }
}

// ======= UTILITY FUNCTIONS =======

// Format price as currency
function formatPrice(price) {
  return `$${Number(price).toFixed(2)}`;
}

// Get random item from array
function getRandomItem(array) {
  return array[Math.floor(Math.random() * array.length)];
}

// Debounce function to limit function calls
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// Smooth scroll to element
function smoothScrollTo(elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
}

// ======= INITIALIZATION =======
document.addEventListener('DOMContentLoaded', () => {
  // Initialize vinyl animation
  const vinylAnimation = new VinylAnimation();
  vinylAnimation.play();
  
  // Initialize audio visualizer if element exists
  if (document.querySelector('.audio-visualizer')) {
    const visualizer = new AudioVisualizer('audioVisualizer', 10);
    visualizer.start();
  }
  
  // Initialize particle system if element exists
  if (document.querySelector('.particles-container')) {
    const particles = new ParticleSystem('particlesContainer', 50);
  }
  
  // Initialize product filters
  const vinylFilter = new ProductFilter('grid-vinyl', '#shopPage .filter-btn');
  const funkosFilter = new ProductFilter('grid-funkos', '#funkosPage .filter-btn');
  const collectiblesFilter = new ProductFilter('grid-collectibles', '#collectiblesPage .filter-btn');
  
  // Initialize product sorters
  const vinylSorter = new ProductSorter('grid-vinyl', 'sortBy');
  const funkosSorter = new ProductSorter('grid-funkos', 'funkosSortBy');
  const collectiblesSorter = new ProductSorter('grid-collectibles', 'collectiblesSortBy');
  
  // Initialize wishlist manager
  const wishlist = new WishlistManager();
  
  // Initialize recently viewed if element exists
  if (document.getElementById('recentlyViewed')) {
    const recentlyViewed = new RecentlyViewed('recentlyViewed');
    recentlyViewed.render();
    
    // Add to recently viewed when viewing product
    window.addToRecentlyViewed = (product) => {
      recentlyViewed.addItem(product);
    };
  }
  
  // Initialize newsletter popup if element exists
  if (document.getElementById('newsletterPopup')) {
    const newsletterPopup = new NewsletterPopup('newsletterPopup');
  }
  
  // Initialize product recommendations if element exists
  if (document.getElementById('productRecommendations')) {
    const recommendations = new ProductRecommendations('productRecommendations');
    
    // Set products when they're loaded
    window.setRecommendationProducts = (products) => {
      recommendations.setProducts(products);
    };
    
    // Render recommendations for a product
    window.showRecommendations = (product) => {
      recommendations.render(product);
    };
  }
  
  // Initialize search if elements exist
  if (document.getElementById('searchInput') && document.getElementById('searchResults')) {
    const search = new ProductSearch('searchInput', 'searchResults');
    
    // Set products when they're loaded
    window.setSearchProducts = (products) => {
      search.setProducts(products);
    };
  }
});