// Dummy content for script.js
